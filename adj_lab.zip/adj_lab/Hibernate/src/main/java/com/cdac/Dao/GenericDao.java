package com.cdac.Dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cdac.entity.Album;

import com.cdac.entity.Employee;

public class GenericDao {

	
	public void Save(Object obj) {
		//During this step, the persistence.xml file will be read
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		
		EntityManagerFactory emf1 = Persistence.createEntityManagerFactory("learning-hibernate");
		try
		{		EntityManager em = emf1.createEntityManager();
				EntityTransaction tx = em.getTransaction();
				tx.begin();
				
				em.merge(obj); //persist method will generate insert query
				 
				tx.commit();
	    }
	finally 
	    {
				emf1.close();
		}
   }
	 public Object fetchById(Class clazz, Object pk) {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
			
		try  {	
			EntityManager em = emf.createEntityManager();
			
			Object obj = em.find(clazz,pk);
		        return obj;
		 }
		finally
		{
			
			emf.close();	
		}
	 }
	 
	 public void delete(Class clazz, Object pk) {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
			try {
				EntityManager em = emf.createEntityManager();
				EntityTransaction tx = em.getTransaction();
				tx.begin();

				//find method generates select query where pk = ?
				Object obj = em.find(clazz, pk);
				em.remove(obj); //remove will generate delete query
				
				tx.commit();
			}
			finally {
				emf.close();
			}
			
		}

}
