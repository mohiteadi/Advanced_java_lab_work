package com.cdac.app;

import java.util.List;

import com.cdac.Dao.CustomerAddressDao;
import com.cdac.entity.Address;
import com.cdac.entity.Customer;

public class AddCustomerAndAddress {
   
	public static void main(String[] args) {
		 CustomerAddressDao dao = new CustomerAddressDao();
		
		
	/*	Customer c = new Customer();
		c.setName("Majrul");
		c.setEmail("majrul@gmail.com");
		dao.add(c);
		
		Address a = new Address();
		a.setPincode(400001);
		a.setCity("Mumbai");
		a.setState("Maharashtra");
	     dao.add(a);
	*/
		
	/*	Customer c = dao.fetchCustomer(1);
		Address a = dao.fetchAddress(1);
		
		c.setAddress(a);
		dao.update(c);
	*/	
	/*	Customer c = new Customer();
		c.setName("Pranav");
		c.setEmail("Pranav@gmail.com");
		
		Address a = new Address();
		a.setPincode(400002);
		a.setCity("Mumbai");
		a.setState("Maharashtra");
	    
	     c.setAddress(a);
	     dao.add(c);
	     */
	/*     Customer c = dao.fetchCustomer(3);
			Address a = dao.fetchAddress(3);
			
			c.setAddress(a);
			dao.update(c); */
		
		
	/*	Customer c = new Customer();
		c.setName("Mohini");
		c.setEmail("Mohini@outlook.com");
		
		Address a = new Address();
		a.setPincode(411023);
		a.setCity("Pune");
		a.setState("Maharashtra");
	    
	     c.setAddress(a);
	     dao.add(c);
	     */
	     
	 	
	/*		Customer c = new Customer();
			c.setName("Aditya");
			c.setEmail("Aditya@outlook.com");
			
			Address a = new Address();
			a.setPincode(411023);
			a.setCity("Pune");
			a.setState("Maharashtra");
		    
		     c.setAddress(a);
		     dao.add(c);
	 } */
 //CustomerAddressDao dao = new CustomerAddressDao();
  /*   List<Customer> list =  dao.fetchAllByCustomersByEmail("outlook");
		// List<Customer> list = dao.fetchAllByCity("Mumbai");
	for(Customer c :list)
		System.out.println(c.getName()+ "" +c.getEmail()+ "" +c.getId());  */
		
		Address a = dao.fetchAddressByCustomerName("Majrul");
		System.out.println(a.getId() + " " + a.getCity() + " " + a.getPincode() + " " + a.getState());
		
	}
}
