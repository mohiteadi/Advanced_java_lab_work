package com.cdac.app;

import java.time.LocalDate;
import java.util.List;

import com.cdac.Dao.AlbumSongDao;
import com.cdac.Dao.GenericDao;
import com.cdac.entity.Album;
import com.cdac.entity.Song;



public class AlbumSongEx {
  public static void main(String[] args) {
	  
	 // GenericDao dao = new GenericDao();
	  AlbumSongDao dao = new AlbumSongDao();
	/*  Album album = new Album();
	   album.setName("Hits of 2021");
	   album.setReleasedate(LocalDate.of(2021, 12,25));
	   album.setCopyright("Sony Music");
	    dao.Save(album);
	    */
	  
	  
	/*  Album album = new Album();
	   album.setName("Hits of 2020");
	   album.setReleasedate(LocalDate.of(2020, 12,15));
	   album.setCopyright("Amazon Music");
	    dao.Save(album);
	    */
	/*   Album album = (Album) dao.fetchById(Album.class,1);
	    Song song = new Song();
		song.setTitle("ghi");
		song.setArtist("Beyonce");
		song.setDuration(3.35);
		song.setAlbum(album);
		dao.Save(song);  */
	  
	/*  Album album = (Album) dao.fetchById(Album.class,2);
	    Song song = new Song();
		song.setTitle("stu");
		song.setArtist(" Taylor smith");
		song.setDuration(4.55);
		song.setAlbum(album);
		dao.Save(song);  */
	  

	  List<Song> songs = dao.fetchSongsSungBy("Beyonce");
		for(Song song : songs)
			System.out.println(song.getTitle() + " " + song.getDuration()); 
		
	//	dao.delete(Song.class, 8);
  }
}
