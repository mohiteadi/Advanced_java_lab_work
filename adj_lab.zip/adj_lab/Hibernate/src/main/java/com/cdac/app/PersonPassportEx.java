package com.cdac.app;

import java.time.LocalDate;
import java.util.List;

import com.cdac.Dao.PersonPassportDao;
import com.cdac.entity.Person;

public class PersonPassportEx {

	   public static void main(String[] args) {
		   PersonPassportDao dao = new PersonPassportDao();
			  
	/*	   Person p = new Person();
		   p.setName("Aditya");
		   p.setEmail("Aditya@gmail.com");
		   p.setDateOfBirth(LocalDate.of(1999, 12, 5));
		   
		  
	       Passport ps = new Passport();
	        ps.setIssuedDate(LocalDate.of(2020, 3, 8));
	       ps.setExpiryDate(LocalDate.of(2030, 6, 9));
	       ps.setIssedBy("Govt. of India");
	       
	       p.setPassport(ps);
	       ps.setPerson(p);
	       dao.add(p);  
	       
	       */
	/*	  Person p = dao.fetchPersonByPassportNo(3);
		   System.out.println(p.getName()+ " "+p.getEmail());
		*/  
		   List<Person>list =  dao.fetchPersonsByExpiryDate(2030);
		   for(Person p : list)
			   System.out.println(p.getName()+ " "+p.getEmail());
		   
		  
	   }
	}
