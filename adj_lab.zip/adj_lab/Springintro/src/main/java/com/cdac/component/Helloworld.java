package com.cdac.component;

public class Helloworld {
       
	public String sayHello(String name) {
		return "Hello" +name;
	}
}
