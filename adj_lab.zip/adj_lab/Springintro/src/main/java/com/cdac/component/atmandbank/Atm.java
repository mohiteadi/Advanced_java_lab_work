package com.cdac.component.atmandbank;

public interface Atm {
   
	public void withdraw(int acno,double amount);
}
