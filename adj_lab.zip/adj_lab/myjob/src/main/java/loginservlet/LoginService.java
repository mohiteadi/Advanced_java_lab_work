package loginservlet;

public class LoginService {

	public boolean logincheck(String username, String password) {
		// TODO Auto-generated method stub
		
		if(username.equals("aditya") && password.equals("123"))
			return true;
			return false;
	}

}
